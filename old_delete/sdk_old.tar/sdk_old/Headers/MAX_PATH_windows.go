package Headers

import "syscall"

const (
	MAX_PATH = syscall.MAX_PATH
)
