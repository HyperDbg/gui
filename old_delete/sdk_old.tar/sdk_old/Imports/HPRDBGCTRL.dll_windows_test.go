package Imports

import "testing"

func TestGenDllMethodsName(t *testing.T) {
	Init()
}
