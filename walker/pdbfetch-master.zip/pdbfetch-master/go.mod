module pdbfetch

go 1.24.0

toolchain go1.24.9

require github.com/edsrzf/mmap-go v1.2.0

require golang.org/x/sys v0.37.0 // indirect
