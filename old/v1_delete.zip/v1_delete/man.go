package main

import (
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/container"
	"github.com/ddkwork/hyperdbgui/ux/asserts"
	"github.com/ddkwork/hyperdbgui/v1_delete/fnTable"
	"github.com/ddkwork/hyperdbgui/v1_delete/meau"
	"github.com/ddkwork/hyperdbgui/v1_delete/toolbar"
	"github.com/fpabl0/sparky-go/swid"
)

func main() {
	a := app.NewWithID("org.hyperdbg")
	a.SetIcon(fyne.NewStaticResource("ico1", asserts.Ico1))
	w := a.NewWindow("Hyper Debugger")
	w.SetMaster()
	w.SetPadded(false)
	h := New()
	w.SetMainMenu(h.MainMenu())
	w.CenterOnScreen()
	w.SetContent(h.CanvasObject(w))
	w.ShowAndRun()
}

type (
	object struct{ mainMenu *fyne.MainMenu }
)

func New() *object                         { return &object{mainMenu: fyne.NewMainMenu()} }
func (o *object) MainMenu() *fyne.MainMenu { return o.mainMenu }
func (o *object) CanvasObject(window fyne.Window) fyne.CanvasObject {
	//todo init dll herw

	topMeau := meau.New()
	o.mainMenu.Items = make([]*fyne.Menu, 0)
	o.mainMenu.Items = append(o.mainMenu.Items,
		topMeau.File(),
		topMeau.View(),
		topMeau.Debug(),
		topMeau.Trace(),
		topMeau.Plugin(),
		topMeau.Favor(),
		topMeau.Option(),
		topMeau.Help(),
	)
	// ImmediateData   window and register window redesign
	// hide all table header,need api set
	command := swid.NewSelectEntryFormField("command", "", []string{"default", "script"})
	command.Hint = "Hyper Debugger is running ..."
	return container.NewBorder(toolbar.New().CanvasObject(nil), command, nil, nil, fnTable.New().CanvasObject(window))
}
